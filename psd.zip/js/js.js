/*global $,alert,console*/
$(function() {
  "use strict";
    
   
  //scroll
  $(window).scroll(function() {
    var nav = $(".navbar");
    if ($(window).scrollTop() >= nav.height()) {
      nav.addClass("scrolled");
    } else {
      nav.removeClass("scrolled");
    }
  });
  //tabs
  $(".tab li ").click(function() {
    $(this)
      .addClass("active")
      .siblings()
      .removeClass("active");
    $(".tab .tab-content> div").hide();
    $($(this).data("class")).fadeIn(100);
    // .show(100);

    window.console.log($(this).data("class"));
  });
  $(".navbar li a").click(function(e) {
    e.preventDefault();
    $("html,body").animate(
      {
        scrollTop: $($(this).data("value")).offset().top
      },
      3000
    );
  });
    
    
  /*  $("body").niceScroll({
  cursorcolor:"aquamarine",
  cursorwidth:"24px",
  background:"rgba(20,20,20,0.3)",
  cursorborder:"1px solid aquamarine",
  cursorborderradius:0
 
});*/
  
});
//loading
$(window).load(function() {
  $(".loading").fadeOut(2000);
});
